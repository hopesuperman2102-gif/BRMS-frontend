// app/src/modules/feature-flags/page/FeatureFlagPage.tsx

"use client";

import FeatureFlagComponent from "../components/Featureflagcomponent";

export default function FeatureFlagPage() {
  return <FeatureFlagComponent />;
}